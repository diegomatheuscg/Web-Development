import { FunctionComponent } from "react";
import CourseFormContainer from "../components/CourseFormContainer";
import styles from "./InstrutorMeusCursosCriar.module.css";

const InstrutorMeusCursosCriar: FunctionComponent = () => {
  return (
    <div className={styles.instrutorMeusCursosCriar}>
      <div className={styles.rodap}>
        <div className={styles.logo}>
          <div className={styles.unifatecieCentroUniversitari} />
          <div className={styles.credenciadaPeloMinistrioContainer}>
            <p className={styles.credenciadaPeloMinistrio}>
              Credenciada pelo Ministério da Educação - MEC
            </p>
            <p className={styles.credenciadaPeloMinistrio}>
              por meio da Portaria 1,179 de 5/12/2007, publicada
            </p>
            <p className={styles.credenciadaPeloMinistrio}>
              ou D.O.U de 6/12/2007.
            </p>
          </div>
        </div>
        <div className={styles.pginas}>
          <div className={styles.title}>
            <b className={styles.pginas1}>Páginas</b>
          </div>
          <div className={styles.sobreNs}>Sobre nós</div>
          <div className={styles.sobreNs}>Cursos</div>
          <div className={styles.sobreNs}>{`Termos & Condições`}</div>
        </div>
        <div className={styles.dvidas}>
          <div className={styles.title}>
            <b className={styles.pginas1}>Dúvidas</b>
          </div>
          <div className={styles.ajudeMe}>Ajude-me</div>
          <div className={styles.ajudeMe}>Suporte</div>
          <div className={styles.ajudeMe}>Política de Privacidade</div>
        </div>
        <div className={styles.contatos}>
          <div className={styles.title2}>
            <b className={styles.contatos1}>Contatos</b>
          </div>
          <div className={styles.line1}>
            <div className={styles.phone}>
              <div className={styles.phone1}>phone</div>
            </div>
            <div className={styles.telefone}>Telefone:</div>
            <div className={styles.div}>3045-9898</div>
          </div>
          <div className={styles.line1}>
            <div className={styles.phone}>
              <div className={styles.mapMarkedAlt1}>map-marked-alt</div>
            </div>
            <div className={styles.telefone}>Endereço:</div>
            <div className={styles.div}>BR-376 KM 102</div>
          </div>
          <div className={styles.line1}>
            <div className={styles.phone}>
              <div className={styles.mapMarkedAlt1}>volume</div>
            </div>
            <div className={styles.telefone}>Paranavaí:</div>
            <div className={styles.div}>PR, 87701-000</div>
          </div>
          <div className={styles.line1}>
            <div className={styles.phone}>
              <div className={styles.mapMarkedAlt1}>mailbox</div>
            </div>
            <div className={styles.telefone}>E-mail:</div>
            <div className={styles.growupfatecieedubr}>
              growup@fatecie.edu.br
            </div>
          </div>
        </div>
        <div className={styles.rodapChild} />
      </div>
      <CourseFormContainer />
      <div className={styles.headWrapper}>
        <div className={styles.head}>
          <div className={styles.topBar} />
          <div className={styles.logounifatecie} />
          <div className={styles.boto2Wrapper}>
            <div className={styles.boto2}>
              <div className={styles.leadIcon}>
                <div className={styles.heart}>heart</div>
              </div>
              <b className={styles.realizarPagamento}>Sair</b>
              <div className={styles.leadIcon}>
                <div className={styles.heart}>edit</div>
              </div>
              <div className={styles.leadIcon}>
                <div className={styles.times}>times</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.statusBar}>
        <div className={styles.statusBarChild} />
        <div className={styles.aInstituioQueMaisCresceParent}>
          <div className={styles.aInstituioQue}>
            A instituição que mais cresce no Brasil.
          </div>
          <b className={styles.growupfatecieedubr}>UniFatecie</b>
          <div className={styles.arrowRight}>
            <div className={styles.arrowRight1}>arrow-right</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstrutorMeusCursosCriar;
