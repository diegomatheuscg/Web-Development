import { FunctionComponent } from "react";
import styles from "./ExternalLinkAlt.module.css";

const ExternalLinkAlt: FunctionComponent = () => {
  return <div className={styles.externalLinkAlt}>external-link-alt</div>;
};

export default ExternalLinkAlt;
