import { FunctionComponent } from "react";
import ExternalLinkAlt from "./ExternalLinkAlt";
import styles from "./CourseFormContainer.module.css";


const CourseFormContainer: FunctionComponent = () => {
  return (
    <div className={styles.content}>
      <div className={styles.title}>
        <b className={styles.criarCurso}>Criar Curso</b>
        <div className={styles.vocNoTem}>
          Você não tem cursos criados no momento. Para criar um, selecione qual
          tipo de curso deseja criar:
        </div>
      </div>
      <div className={styles.cards}>
        <div className={styles.card}>
          <b className={styles.oQueSo}>O que são Cursos Livres?</b>
          <div className={styles.cardChild1} />
          <div className={styles.frameParent}>
            <div className={styles.frameWrapper}>
              <div className={styles.osDadosDosCursosLivresQueParent}>
                <div className={styles.osDadosDosContainer}>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    <span className={styles.osDadosDos}>{`Os dados dos `}</span>
                    <b className={styles.osDadosDos}>cursos livres</b>
                    <span>
                      {" "}
                      que o Instrutor deve fornecer antes de ser aceita serão:
                    </span>
                  </p>
                  <ul className={styles.ttuloDoCursoDescrioDoC}>
                    <li className={styles.ttuloDoCurso}>
                      <b>Título do Curso</b>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b>Descrição do Curso</b>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b>Tags do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Lista com as tags já existentes na plataforma e com a
                        opção de adicionar uma nova tags.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Tipo do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Radio Button com a opção de “Pós-Graduação”
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Valor do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Tipo de moeda Reais
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Duração do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Campo de texto em horas
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Imagem da Capa:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Form para upload de um arquivo de imagem com uma label
                        para a recomendação da proporção da imagem
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Vídeo Promocional:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Form para upload de link Youtube/Vimeo.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Nome das Disciplinas:</b>
                      <span className={styles.osDadosDos}> (opcional).</span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Nome dos Módulos:</b>
                      <span> (opcional).</span>
                    </li>
                  </ul>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Os dados que o próprio sistema irá fornecer será:
                  </p>
                  <ul className={styles.ttuloDoCursoDescrioDoC}>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        Nome do Instrutor: Pegar nome de usuário do Instrutor
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        Validade do Curso: Carga horária restante para concluir
                        a pós-graduação.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        A carga horária não é fixa, depende do Instrutor.
                      </span>
                    </li>
                  </ul>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Possui “n” disciplinas dentro do curso de pós-graduação.
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Possui “n” módulos dentro de cada disciplina.
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                </div>
                <div className={styles.button1}>
                  <div className={styles.leadIcon}>
                    <div className={styles.heart}>heart</div>
                  </div>
                  <div className={styles.confirmar}>Ver Descrição Completa</div>
                  <div className={styles.icon1}>
                    <div className={styles.heart}>external-link-alt</div>
                  </div>
                  <div className={styles.leadIcon}>
                    <div className={styles.times}>times</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.frameItem} />
            </div>
          </div>
          <div className={styles.button11}>
            <div className={styles.leadIcon}>
              <div className={styles.heart}>heart</div>
            </div>
            <b className={styles.realizarPagamento}>Criar Curso Livre</b>
            <div className={styles.icon1}>
              <div className={styles.heart}>external-link-alt</div>
            </div>
            <div className={styles.leadIcon}>
              <div className={styles.times}>times</div>
            </div>
          </div>
        </div>
        <div className={styles.card}>
          <b className={styles.oQueSo}>O que são Cursos Premium?</b>
          <div className={styles.cardChild2} />
          <div className={styles.frameParent}>
            <div className={styles.frameWrapper}>
              <div className={styles.osDadosDosCursosLivresQueParent}>
                <div className={styles.osDadosDosContainer}>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    <span className={styles.osDadosDos}>{`Os dados dos `}</span>
                    <b className={styles.osDadosDos}>cursos premium</b>
                    <span>
                      {" "}
                      que o Instrutor deve fornecer antes de ser aceita serão:
                    </span>
                  </p>
                  <ul className={styles.ttuloDoCursoDescrioDoC}>
                    <li className={styles.ttuloDoCurso}>
                      <b>Título do Curso</b>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b>Descrição do Curso</b>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b>Tags do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Lista com as tags já existentes na plataforma e com a
                        opção de adicionar uma nova tags.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Tipo do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Radio Button com a opção de “Pós-Graduação”
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Valor do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Tipo de moeda Reais
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Duração do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Campo de texto em horas
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Imagem da Capa:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Form para upload de um arquivo de imagem com uma label
                        para a recomendação da proporção da imagem
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Vídeo Promocional:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Form para upload de link Youtube/Vimeo.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Nome das Disciplinas:</b>
                      <span className={styles.osDadosDos}> (opcional).</span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Nome dos Módulos:</b>
                      <span> (opcional).</span>
                    </li>
                  </ul>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Os dados que o próprio sistema irá fornecer será:
                  </p>
                  <ul className={styles.ttuloDoCursoDescrioDoC}>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        Nome do Instrutor: Pegar nome de usuário do Instrutor
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        Validade do Curso: Carga horária restante para concluir
                        a pós-graduação.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        A carga horária não é fixa, depende do Instrutor.
                      </span>
                    </li>
                  </ul>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Possui “n” disciplinas dentro do curso de pós-graduação.
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Possui “n” módulos dentro de cada disciplina.
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                </div>
                <div className={styles.button12}>
                  <div className={styles.leadIcon}>
                    <div className={styles.heart}>heart</div>
                  </div>
                  <div className={styles.confirmar}>Ver Descrição Completa</div>
                  <div className={styles.icon12}>
                    <div className={styles.heart}>external-link-alt</div>
                  </div>
                  <div className={styles.leadIcon}>
                    <div className={styles.times}>times</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.frameItem} />
            </div>
          </div>
          <div className={styles.button11}>
            <div className={styles.leadIcon}>
              <div className={styles.heart}>heart</div>
            </div>
            <b className={styles.realizarPagamento}>Criar Curso Premium</b>
            <div className={styles.icon1}>
              <ExternalLinkAlt />
            </div>
            <div className={styles.leadIcon}>
              <div className={styles.times}>times</div>
            </div>
          </div>
        </div>
        <div className={styles.card}>
          <b className={styles.oQueSo}>O que são Cursos de Pós-Graduação?</b>
          <div className={styles.cardChild3} />
          <div className={styles.frameParent}>
            <div className={styles.frameWrapper}>
              <div className={styles.osDadosDosCursosLivresQueParent}>
                <div className={styles.osDadosDosContainer}>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    <span
                      className={styles.osDadosDos}
                    >{`Os dados do curso de `}</span>
                    <b className={styles.osDadosDos}>pós-graduação</b>
                    <span> que o Instrutor deve</span>
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    fornecer antes de ser aceita serão:
                  </p>
                  <ul className={styles.ttuloDoCursoDescrioDoC}>
                    <li className={styles.ttuloDoCurso}>
                      <b>Título do Curso</b>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b>Descrição do Curso</b>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b>Tags do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Lista com as tags já existentes na plataforma e com a
                        opção de adicionar uma nova tags.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Tipo do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Radio Button com a opção de “Pós-Graduação”
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Valor do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Tipo de moeda Reais
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Duração do Curso:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Campo de texto em horas
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Imagem da Capa:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Form para upload de um arquivo de imagem com uma label
                        para a recomendação da proporção da imagem
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Vídeo Promocional:</b>
                      <span className={styles.osDadosDos}>
                        {" "}
                        Form para upload de link Youtube/Vimeo.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Nome das Disciplinas:</b>
                      <span className={styles.osDadosDos}> (opcional).</span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <b className={styles.osDadosDos}>Nome dos Módulos:</b>
                      <span> (opcional).</span>
                    </li>
                  </ul>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Os dados que o próprio sistema irá fornecer será:
                  </p>
                  <ul className={styles.ttuloDoCursoDescrioDoC}>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        Nome do Instrutor: Pegar nome de usuário do Instrutor
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        Validade do Curso: Carga horária restante para concluir
                        a pós-graduação.
                      </span>
                    </li>
                    <li className={styles.ttuloDoCurso}>
                      <span>
                        A carga horária não é fixa, depende do Instrutor.
                      </span>
                    </li>
                  </ul>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Possui “n” disciplinas dentro do curso de pós-graduação.
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                  <p className={styles.osDadosDosCursosLivresQue}>
                    Possui “n” módulos dentro de cada disciplina.
                  </p>
                  <p className={styles.osDadosDosCursosLivresQue}>&nbsp;</p>
                </div>
                <div className={styles.button12}>
                  <div className={styles.leadIcon}>
                    <div className={styles.heart}>heart</div>
                  </div>
                  <div className={styles.confirmar}>Ver Descrição Completa</div>
                  <div className={styles.icon12}>
                    <div className={styles.heart}>external-link-alt</div>
                  </div>
                  <div className={styles.leadIcon}>
                    <div className={styles.times}>times</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.frameItem} />
            </div>
          </div>
          <div className={styles.button11}>
            <div className={styles.leadIcon}>
              <div className={styles.heart}>heart</div>
            </div>
            <b className={styles.realizarPagamento}>
              Criar Curso Pós-Graduação
            </b>
            <div className={styles.icon1}>
              <div className={styles.heart}>external-link-alt</div>
            </div>
            <div className={styles.leadIcon}>
              <div className={styles.times}>times</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseFormContainer;
